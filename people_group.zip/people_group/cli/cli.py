from generator.local.local import Group
import click

@click.group()
def cli():
    pass

@click.command()
@click.option('-f/-n', default = False, help = "f - заполнить группу автоматически, иначе создаёт пустую группу") # autofill
@click.option('-s', '-size', default = 0, help = "размер группы")
@click.option('-n', '-group_name', help = "название группы")
@click.option('-sort', default = 'name', help = "сортировать группо по параметру (по умолчанию имя)")
@click.option('-d', '-folder_name', default = None, help = "название папки для группы (по умолчанию совпадает с именем группы)")
def create_group(s, sort, n, d, f):
    g = Group(size = int(s), name = n, directory = d, autofill = f)
    g.save_group(sort = sort)
    
@click.command()
@click.option('-f/-n', default = False, help = "-f - удалить также папку группы")
@click.option('-n', '-group_name', help = "название группы")
@click.option('-d', '-folder_name', type = click.Path(exists = True), default = None, help = "папка группы")
def delete_group(n, d, f):
    g = Group(size = 0, name = n, directory = d)
    if f:
        g.delete_group()
    else:
        g.clean_group()
    
cli.add_command(create_group)
cli.add_command(delete_group)

if __name__ == '__main__':
    cli()
    
    
#g = local.Group(10, 'gender', 'Office', autofill = True)


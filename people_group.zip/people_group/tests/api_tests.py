import json
from generator.api import api
from generator.api import constants

def test_request():
    a = api.API()
    a.request_data('http://Bad_URL')
    assert response == None, "Некорректный адрес запроса"
    
def test_response():
    a = api.API()
    r = a.request_data(constants.PERSON_URL)
    r = json.loads(r.text)
    assert "education" in r.keys(), "Загрузились не все данные о человеке"
    assert "marriage" in r.keys(), "Загрузились не все данные о человеке"
    assert "online_info" in r.keys(), "Загрузились не все данные о человеке"
    assert "personal" in r.keys(), "Загрузились не все данные о человеке"
    assert "work" in r.keys(), "Загрузились не все данные о человеке"
#import json
import os
import pytest
from generator.local import local
#from generator.api import api
#from generator.local import local_constants

def test_group():
    g = local.Group(3)
    assert g.size == 3, "Некорректный размер для новой группы"
    assert g.group_name == 'groups\\Random bystanders', "Некорректное название группы по умолчанию"
    assert os.path.basename(os.path.dirname(os.getcwd())) == 'people_group', 'Некорректно определился путь к папке по умолчанию'
    
    g = local.Group(3, name = 'Group')
    assert g.group_name == 'groups\\Group'
    
    g = local.Group(3, directory = 'D:\\')
    assert g.dir == 'D:\\'
    
    assert str (g) == 'Group of 3 people (0 with personal data)'
    
def test_fill():
    g = local.Group(3)
    g.fill_from_api()
    assert g.size == 3
    assert len (g.members) == 3
    assert type(g.members[0]) == local.Person
    assert str (g) == 'Group of 3 people (3 with personal data)'
    
def test_save():
    g = local.Group(5)
    previous_dir = g.dir
    g.save_group(sort = 'gender', newname = 'TestNewGroup')
    assert os.path.dirname(g.dir) == os.path.dirname(previous_dir), "В процессе сохранения изменился путь к папке"
    os.rmdir(g.dir)
    
def test_load():
    g = local.Group(5)
    g.load_group('Test Group')
    assert g.size == 10
    assert g.group_name == 'groups\\Test Group'
    
    g = local.Group(20)
    d = os.getcwd()
    while os.path.basename(d) != 'people_group':
        d = os.path.dirname(d)
    d = os.path.join(d, 'groups\\Test Group')
    g.load_group(directory = d)
    assert str (g) == 'Group of 20 people (10 with personal data)'
    
    g = local.Group(0)
    with pytest.raises(AttributeError):
        g.load_group(name = '123', directory = '456')
    
def test_person():
    p = local.Person()
    assert p.name == ' '
    
def test_process():
    p = local.Person()
    p.process_person()
    
if __name__ == '__main__':
    test_group()
    test_fill()
    test_save()
    test_load()
    test_person()
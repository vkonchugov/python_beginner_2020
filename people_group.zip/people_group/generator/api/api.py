import requests

class API:
    
    def __init__(self):
        pass
    
    def request_data (self, url):
        response = requests.get(url)
        response.raise_for_status()
        return response
    
if __name__ == '__main__':
    a = API()
    a.request_data('https://pipl.ir/v1/getPerson')
PERSON_URL = r"https://pipl.ir/v1/getPerson"
TEXT_URL = r"https://loripsum.net/api"
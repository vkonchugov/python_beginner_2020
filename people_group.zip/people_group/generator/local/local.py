import os
from generator.api import api, constants
import json
import shutil
from requests import Response
from generator.local.local_constants import DEFAULT_GROUP_NAME
from generator.local.nested_get_key import get_key

class Group:
    
    def __init__ (self, size, name = DEFAULT_GROUP_NAME, directory = None, autofill = False):
        self.size = size
        self.members = []
        name = os.path.join('groups', name)
        if directory:
            self.dir = directory
        else:
            self.dir = os.getcwd()
            while os.path.basename(self.dir) != 'people_group':
                self.dir = os.path.dirname(self.dir)
            self.dir = os.path.join(self.dir, name)
        self.group_name = name
        if autofill:
            self.fill_from_api()
            
    def fill_from_api (self):
        for ppl in range(self.size):
            p = Person(True)
            self.members.append(p)

    def save_group (self, sort = 'name', newname = None):
        
        if newname:
            self.dir = os.path.join(os.path.dirname(self.dir), newname)
        
        if not os.path.exists(self.dir):
            os.makedirs(self.dir)
        
        for ppl in self.members:
            keydir = os.path.join(self.dir, str(get_key(sort, ppl.data)))
            keyname = ppl.name
            if not os.path.exists(keydir):
                os.makedirs(keydir)
            with open (os.path.join(keydir, keyname) + '.json', 'w+') as file:
                json.dump(ppl.data, file)
                    
    def delete_group (self): # Удаляет все файлы в папке группы и саму папку
        shutil.rmtree (self.dir)
        
    def clean_group (self): # Удаляет все файлы в папке группы
        for root, dirs, files in os.walk(self.dir):
            for f in files:
                os.unlink(os.path.join(root, f))
            for d in dirs:
                shutil.rmtree(os.path.join(root, d))
                
    def load_group (self, name = None, directory = None): # Добавляет данные по людям из группы на диске в текущую группу
        if directory and not name:
            self.dir = directory
            self.group_name = os.path.basename(self.dir)
        elif name and not directory:
            self.group_name = os.path.join('groups', name)
            self.dir = os.getcwd()
            while os.path.basename(self.dir) != 'people_group':
                self.dir = os.path.dirname(self.dir)
            self.dir = os.path.join(self.dir, self.group_name)
        else:
            raise AttributeError ("Для загрузки группы необходимо указать одно: название группы или директорию")
        for person_list in os.walk(self.dir):
            for pers in person_list[2]:
                with open (os.path.join(person_list[0], pers), 'r') as file:
                    req = json.load(file)
                p = Person()
                p.process_person(request = req)
                self.members.append(p)
        self.size = max(self.size, len(self.members))
        
    def __str__(self):
        if self.size == 0:
            return "Empty people group"
        else:
            return f"Group of {self.size} people ({len(self.members)} with personal data)"
        
    def __repr__(self):
        return self.__str__()

class Person:
    
    def __init__(self, autocreate = False):
        self.fname = ""
        self.lname = ""
        self.data = None
        if autocreate:
            self.process_person()
    
    @property
    def name(self):
        return self.fname + " " + self.lname

    def process_person (self, request = None):
        if request == None:
            person = json.loads(api.API().request_data(constants.PERSON_URL).text)
            person = person['person']
        elif isinstance(request, Response):
            person = request.text
            person = person['person']
        elif isinstance(request, dict):
            person = request
        else:
            person = json.loads(request.text)
        self.fname = person['personal']['name']
        self.lname = person['personal']['last_name']
        self.age = person['personal']['age']
        self.gender = person['personal']['gender']
        self.city = person['personal']['city']
        self.data = person
        return person
    
    def __str__(self):
        return f"{self.name}: {self.gender} of {self.age} from {self.city}"
    
    def __repr__ (self):
        return self.__str__()

if __name__ == '__main__':
    g = Group (3)
    g.load_group('Random bystanders')
    g.save_group('age', 'Office')
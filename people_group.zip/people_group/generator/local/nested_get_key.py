"""Nested search in multilayered dictionary"""

def get_key (key, dct):
    if key in dct:
        return dct[key]
    for k in dct:
        try:
            return get_key(key, dct[k])
        except (TypeError, ValueError):
            pass
    else:
        raise ValueError

def get_keys (key, dct):
    ls = []
    if key in dct:
        ls.append(dct[key])
    for k in dct:
        try:
            u = get_keys(key, dct[k])
            if u:
                ls.append(u)
        except (TypeError, ValueError):
            pass
    return ls